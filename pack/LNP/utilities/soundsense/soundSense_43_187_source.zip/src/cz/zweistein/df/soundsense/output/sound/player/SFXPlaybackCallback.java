package cz.zweistein.df.soundsense.output.sound.player;

public interface SFXPlaybackCallback {
	
	void started();
	
	void ended();

}
