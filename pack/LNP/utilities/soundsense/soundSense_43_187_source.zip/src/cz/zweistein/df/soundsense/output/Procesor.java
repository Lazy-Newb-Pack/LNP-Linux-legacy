package cz.zweistein.df.soundsense.output;

public abstract class Procesor {
	
	public abstract void processLine(String line);

}
